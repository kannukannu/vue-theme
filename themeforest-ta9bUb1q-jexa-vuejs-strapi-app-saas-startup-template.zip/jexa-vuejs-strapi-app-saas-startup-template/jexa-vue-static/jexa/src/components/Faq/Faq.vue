<template>
    <div class="faq-area ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12">
                    <div class="faq-sidebar">
                        <ul>
                            <li><a href="faq"><span>Startup Business Idea</span></a></li>
                            <li><a href="faq"><span>Digital Marketing</span></a></li>
                            <li><a href="faq" class="active"><span>Design and Development</span></a></li>
                            <li><a href="faq"><span>IT and Startup Consulting</span></a></li>
                            <li><a href="faq"><span>Design and Development</span></a></li>
                            <li><a href="faq"><span>Startup Landing Page</span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12">
                    <div class="faq-accordion">
                        <accordion>
                            <accordion-item>
                                <template v-slot:accordion-trigger>
                                <button class="accordion-title">
                                    What is Team Management?
                                </button>
                                </template>
                                <template v-slot:accordion-content>
                                    <div class="accordion-body">
                                        <p><strong>Jexa</strong> is always looking for talented <a href="#">information</a> security and IT risk management professionals who are dedicated, hard working and looking for a challenge. If you are interested in employment with <strong>Jexa</strong>, a company who values you and your family, visit our careers page.</p>
                                        <ul>
                                            <li>a console</li>
                                            <li>Two Joy-Con controllers that are detachable</li>
                                            <li>A grip that enables you to combine them into a single gamepad for play on the TV</li>
                                            <li>Two straps for turning the Joy-Cons into individual controllers</li>
                                            <li>A dock which you can use to connect your console to the television for traditional gameplay</li>
                                        </ul>
                                    </div>
                                </template>
                            </accordion-item>
                            <accordion-item>
                                <template v-slot:accordion-trigger>
                                <button class="accordion-title">
                                   What is the purpose of a consultant?
                                </button>
                                </template>
                                <template v-slot:accordion-content>
                                    <div class="accordion-body">
                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.</p>
                                        <ul>
                                            <li>a console</li>
                                            <li>Two Joy-Con controllers that are <a href="#">detachable</a></li>
                                            <li>A grip that enables you to combine them into a single gamepad for play on the TV</li>
                                            <li>Two straps for turning the Joy-Cons into <strong>individual</strong> controllers</li>
                                            <li>A dock which you can use to connect your console to the television for traditional gameplay</li>
                                        </ul>
                                    </div>
                                </template>
                            </accordion-item>
                            <accordion-item>
                                <template v-slot:accordion-trigger>
                                <button class="accordion-title">
                                    What attracts you to the role of a consultant?
                                </button>
                                </template>
                                <template v-slot:accordion-content>
                                    <div class="accordion-body">
                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor.</p>
                                        <p>Tunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.</p>
                                    </div>
                                </template>
                            </accordion-item>
                            <accordion-item>
                                <template v-slot:accordion-trigger>
                                <button class="accordion-title">
                                    What are the advantages of being a consultant?
                                </button>
                                </template>
                                <template v-slot:accordion-content>
                                    <div class="accordion-body">
                                        <ul>
                                            <li>a console</li>
                                            <li>Two Joy-Con controllers that are detachable</li>
                                            <li>A grip that enables you to combine them into a single gamepad for play on the TV</li>
                                            <li>Two straps for turning the Joy-Cons into individual controllers</li>
                                            <li>A dock which you can use to connect your console to the television for traditional gameplay</li>
                                        </ul>
                                    </div>
                                </template>
                            </accordion-item>
                            <accordion-item>
                                <template v-slot:accordion-trigger>
                                <button class="accordion-title">
                                    Is consulting a good career?
                                </button>
                                </template>
                                <template v-slot:accordion-content>
                                    <div class="accordion-body">
                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.</p>
                                    </div>
                                </template>
                            </accordion-item>
                            <accordion-item>
                                <template v-slot:accordion-trigger>
                                <button class="accordion-title">
                                    How is working in consulting?
                                </button>
                                </template>
                                <template v-slot:accordion-content>
                                    <div class="accordion-body">
                                        <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo.</p>
                                        <ul>
                                            <li>a console</li>
                                            <li>Two Joy-Con controllers that are <a href="#">detachable</a></li>
                                            <li>A grip that enables you to combine them into a single gamepad for play on the TV</li>
                                            <li>Two straps for turning the Joy-Cons into <strong>individual</strong> controllers</li>
                                            <li>A dock which you can use to connect your console to the television for traditional gameplay</li>
                                        </ul>
                                    </div>
                                </template>
                            </accordion-item>
                        </accordion>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Accordion from "../Common/Accordion";
import AccordionItem from "../Common/AccordionItem";

export default {
    name: 'Faq',
    components: {
        Accordion,
        AccordionItem,
    },
}
</script>