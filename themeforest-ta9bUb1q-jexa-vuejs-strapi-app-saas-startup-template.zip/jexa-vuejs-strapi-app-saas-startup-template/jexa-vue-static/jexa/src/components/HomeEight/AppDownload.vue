<template>
    <div class="new-app-download-wrap-area ptb-100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="new-app-download-content">
                        <span class="sub-title">DOWNLOAD APP</span>
                        <h2>Let's Get Your Free Copy From Apple and Play Store</h2>
                        <p>Instant free download from store Cloud based storage for your data backup just log in with your mail account from play store and using whatever you want for your business purpose orem ipsum dummy text.</p>
                        <div class="btn-box color-wrap">
                            <a href="#" class="playstore-btn" target="_blank">
                                <img src="../../assets/images/play-store.png" alt="image">
                                Get It On
                                <span>Google Play</span>
                            </a>
                            <a href="#" class="applestore-btn" target="_blank">
                                <img src="../../assets/images/apple-store.png" alt="image">
                                Download on the
                                <span>Apple Store</span>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="new-app-download-image text-end" data-aos="fade-up">
                        <img src="../../assets/images/more-home/app-download/download-2.png" alt="app-img">

                        <div class="download-circle">
                            <img src="../../assets/images/more-home/app-download/download-circle.png" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="app-download-shape-1">
            <img src="../../assets/images/more-home/app-download/shape-1.png" alt="image">
        </div>
        <div class="app-download-shape-2">
            <img src="../../assets/images/more-home/app-download/shape-2.png" alt="image">
        </div>
    </div>
</template>

<script>
export default {
    name: 'AppDownload'
}
</script>