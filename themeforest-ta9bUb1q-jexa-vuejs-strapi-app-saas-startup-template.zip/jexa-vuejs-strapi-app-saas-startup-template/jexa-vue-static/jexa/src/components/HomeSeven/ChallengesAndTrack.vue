<template>
    <div class="new-app-progress-area ptb-100">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="new-app-progress-content">
                        <div class="big-text">Progress</div>
                        <span class="sub-title">APP PROGRESS</span>
                        <h2>Set Up The Challenges and Track Your Progress</h2>
                        <p>Cloud based storage for your data backup just log in with your mail account from play store and using whatever you want for your business purpose orem ipsum dummy text. never missyour chance its just began. backup just log in with your mail account from.</p>
                        <p>Most provabily best  for your data backup just log in with your mail account from play store and using whatever you want for your business purpose orem ipsum dummy  backup just log in with your mail account from.</p>
                        <router-link to="/app-download" class="default-btn">Start Free Trial</router-link>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="new-app-progress-image text-center">
                        <img src="../../assets/images/more-home/progress/progress.png" alt="app-img">
                    </div>
                </div>
            </div>
        </div>
        <div class="new-app-progress-shape">
            <img src="../../assets/images/more-home/progress/shape-1.png" alt="image">
        </div>
    </div>
</template>

<script>
export default {
    name: 'ChallengesAndTrack'
}
</script>