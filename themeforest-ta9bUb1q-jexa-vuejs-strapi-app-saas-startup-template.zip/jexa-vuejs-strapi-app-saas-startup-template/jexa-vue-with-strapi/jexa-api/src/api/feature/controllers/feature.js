'use strict';

/**
 *  feature controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::feature.feature');
