'use strict';

/**
 *  softwareintegration controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::softwareintegration.softwareintegration');
