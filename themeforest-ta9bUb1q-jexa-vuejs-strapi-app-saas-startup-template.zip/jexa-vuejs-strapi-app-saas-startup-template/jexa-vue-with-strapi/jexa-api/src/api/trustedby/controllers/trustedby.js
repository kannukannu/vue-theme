'use strict';

/**
 *  trustedby controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::trustedby.trustedby');
