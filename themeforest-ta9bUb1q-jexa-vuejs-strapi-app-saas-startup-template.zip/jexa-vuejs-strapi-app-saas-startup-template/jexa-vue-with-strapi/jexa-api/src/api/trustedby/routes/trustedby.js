'use strict';

/**
 * trustedby router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::trustedby.trustedby');
