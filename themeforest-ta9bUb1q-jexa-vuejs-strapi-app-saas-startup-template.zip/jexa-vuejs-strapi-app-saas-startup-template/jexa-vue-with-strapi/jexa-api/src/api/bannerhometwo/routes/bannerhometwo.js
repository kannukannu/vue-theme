'use strict';

/**
 * bannerhometwo router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::bannerhometwo.bannerhometwo');
