'use strict';

/**
 * bannerhometwo service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::bannerhometwo.bannerhometwo');
