'use strict';

/**
 *  bannerhometwo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bannerhometwo.bannerhometwo');
