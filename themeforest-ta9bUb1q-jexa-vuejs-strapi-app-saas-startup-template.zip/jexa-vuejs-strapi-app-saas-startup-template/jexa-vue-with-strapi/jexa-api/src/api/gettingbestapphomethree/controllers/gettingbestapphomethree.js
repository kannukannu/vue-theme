'use strict';

/**
 *  gettingbestapphomethree controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::gettingbestapphomethree.gettingbestapphomethree');
