'use strict';

/**
 *  includedbestfeature controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::includedbestfeature.includedbestfeature');
