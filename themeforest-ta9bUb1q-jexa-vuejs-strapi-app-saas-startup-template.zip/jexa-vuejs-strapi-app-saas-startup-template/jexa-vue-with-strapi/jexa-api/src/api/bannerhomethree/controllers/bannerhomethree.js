'use strict';

/**
 *  bannerhomethree controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bannerhomethree.bannerhomethree');
