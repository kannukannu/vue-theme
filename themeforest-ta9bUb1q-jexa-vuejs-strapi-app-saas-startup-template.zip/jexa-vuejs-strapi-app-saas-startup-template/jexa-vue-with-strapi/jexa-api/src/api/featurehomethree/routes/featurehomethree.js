'use strict';

/**
 * featurehomethree router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::featurehomethree.featurehomethree');
