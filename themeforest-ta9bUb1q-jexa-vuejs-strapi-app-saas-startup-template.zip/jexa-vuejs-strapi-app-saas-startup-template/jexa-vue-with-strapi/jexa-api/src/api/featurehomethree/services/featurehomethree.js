'use strict';

/**
 * featurehomethree service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::featurehomethree.featurehomethree');
