'use strict';

/**
 *  featurehomethree controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::featurehomethree.featurehomethree');
