'use strict';

/**
 *  includedbestfeaturehometwo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::includedbestfeaturehometwo.includedbestfeaturehometwo');
