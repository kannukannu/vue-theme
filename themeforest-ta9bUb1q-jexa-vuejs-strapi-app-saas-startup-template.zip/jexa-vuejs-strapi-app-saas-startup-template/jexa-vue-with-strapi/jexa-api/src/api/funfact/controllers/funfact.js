'use strict';

/**
 *  funfact controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::funfact.funfact');
