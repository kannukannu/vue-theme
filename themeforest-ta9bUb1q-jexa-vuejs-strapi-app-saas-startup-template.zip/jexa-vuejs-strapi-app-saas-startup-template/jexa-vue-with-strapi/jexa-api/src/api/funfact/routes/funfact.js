'use strict';

/**
 * funfact router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::funfact.funfact');
