'use strict';

/**
 * sitelogo service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sitelogo.sitelogo');
