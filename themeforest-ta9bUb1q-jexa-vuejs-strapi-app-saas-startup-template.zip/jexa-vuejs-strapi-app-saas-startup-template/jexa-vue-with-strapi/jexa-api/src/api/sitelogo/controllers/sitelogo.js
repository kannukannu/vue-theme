'use strict';

/**
 *  sitelogo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sitelogo.sitelogo');
