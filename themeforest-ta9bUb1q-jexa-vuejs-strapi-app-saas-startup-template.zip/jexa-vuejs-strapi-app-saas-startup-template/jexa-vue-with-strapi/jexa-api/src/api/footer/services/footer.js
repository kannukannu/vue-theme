'use strict';

/**
 * footer service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::footer.footer');
