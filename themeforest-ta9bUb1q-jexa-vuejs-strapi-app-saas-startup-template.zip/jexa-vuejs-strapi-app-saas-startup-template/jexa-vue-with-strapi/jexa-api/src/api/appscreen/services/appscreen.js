'use strict';

/**
 * appscreen service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::appscreen.appscreen');
