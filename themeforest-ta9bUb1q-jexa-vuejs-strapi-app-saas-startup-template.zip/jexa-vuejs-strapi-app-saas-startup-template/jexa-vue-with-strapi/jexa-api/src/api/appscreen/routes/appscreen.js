'use strict';

/**
 * appscreen router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::appscreen.appscreen');
