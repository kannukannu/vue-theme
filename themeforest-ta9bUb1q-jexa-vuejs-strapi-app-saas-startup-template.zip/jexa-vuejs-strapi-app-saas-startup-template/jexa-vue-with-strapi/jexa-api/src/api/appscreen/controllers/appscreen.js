'use strict';

/**
 *  appscreen controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::appscreen.appscreen');
