'use strict';

/**
 *  challengesandtrack controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::challengesandtrack.challengesandtrack');
