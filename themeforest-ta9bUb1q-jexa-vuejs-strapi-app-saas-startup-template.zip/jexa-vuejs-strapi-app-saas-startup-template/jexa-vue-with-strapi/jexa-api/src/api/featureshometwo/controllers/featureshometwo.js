'use strict';

/**
 *  featureshometwo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::featureshometwo.featureshometwo');
