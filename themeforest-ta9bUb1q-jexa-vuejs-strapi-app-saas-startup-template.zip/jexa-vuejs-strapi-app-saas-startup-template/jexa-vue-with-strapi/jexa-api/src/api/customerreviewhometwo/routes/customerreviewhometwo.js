'use strict';

/**
 * customerreviewhometwo router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::customerreviewhometwo.customerreviewhometwo');
