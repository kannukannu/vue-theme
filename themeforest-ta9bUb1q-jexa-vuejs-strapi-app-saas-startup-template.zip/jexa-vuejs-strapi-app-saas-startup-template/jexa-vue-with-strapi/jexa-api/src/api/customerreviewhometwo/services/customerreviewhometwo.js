'use strict';

/**
 * customerreviewhometwo service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::customerreviewhometwo.customerreviewhometwo');
