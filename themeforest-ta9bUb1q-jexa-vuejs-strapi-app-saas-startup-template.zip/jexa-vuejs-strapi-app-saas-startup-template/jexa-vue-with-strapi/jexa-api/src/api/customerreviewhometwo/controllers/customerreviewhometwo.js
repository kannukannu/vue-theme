'use strict';

/**
 *  customerreviewhometwo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::customerreviewhometwo.customerreviewhometwo');
