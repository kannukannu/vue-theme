'use strict';

/**
 * customerreview service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::customerreview.customerreview');
