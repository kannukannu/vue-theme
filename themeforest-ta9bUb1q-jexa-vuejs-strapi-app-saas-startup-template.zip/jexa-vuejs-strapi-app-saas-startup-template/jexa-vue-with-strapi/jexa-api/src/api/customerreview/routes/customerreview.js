'use strict';

/**
 * customerreview router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::customerreview.customerreview');
