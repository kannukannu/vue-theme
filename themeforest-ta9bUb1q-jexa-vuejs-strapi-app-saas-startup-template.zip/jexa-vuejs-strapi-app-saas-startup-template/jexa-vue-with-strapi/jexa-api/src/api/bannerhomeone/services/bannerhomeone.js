'use strict';

/**
 * bannerhomeone service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::bannerhomeone.bannerhomeone');
