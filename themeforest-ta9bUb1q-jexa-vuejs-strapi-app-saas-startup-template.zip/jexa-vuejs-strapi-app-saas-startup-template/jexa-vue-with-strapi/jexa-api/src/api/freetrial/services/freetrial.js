'use strict';

/**
 * freetrial service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::freetrial.freetrial');
