'use strict';

/**
 *  pricinghometwo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::pricinghometwo.pricinghometwo');
