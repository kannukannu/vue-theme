'use strict';

/**
 *  bannerhomefour controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::bannerhomefour.bannerhomefour');
