'use strict';

/**
 * bannerhomefour service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::bannerhomefour.bannerhomefour');
