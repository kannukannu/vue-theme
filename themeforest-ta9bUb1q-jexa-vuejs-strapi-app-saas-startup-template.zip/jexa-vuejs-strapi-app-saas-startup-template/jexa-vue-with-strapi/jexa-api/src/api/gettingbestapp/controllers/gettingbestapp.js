'use strict';

/**
 *  gettingbestapp controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::gettingbestapp.gettingbestapp');
