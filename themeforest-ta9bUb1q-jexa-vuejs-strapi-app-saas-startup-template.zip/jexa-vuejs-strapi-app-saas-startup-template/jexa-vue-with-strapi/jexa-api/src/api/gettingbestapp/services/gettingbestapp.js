'use strict';

/**
 * gettingbestapp service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::gettingbestapp.gettingbestapp');
