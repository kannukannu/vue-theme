module.exports = ({ env }) => ({
  // ...
  upload: {
    // Update your cloudinary credentials here
    config: {
      provider: "cloudinary",
      providerOptions: {
        cloud_name: "do2wma1dv",
        api_key: "646585821258663",
        api_secret: "TsLEd2sW6pE2vsPIPSMLLM0TKvM",
      },
      actionOptions: {
        upload: {},
        delete: {},
      },
    },
  },
  // ...

  "strapi-plugin-populate-deep": {
    config: {
      defaultDepth: 3,
    },
  },
});
